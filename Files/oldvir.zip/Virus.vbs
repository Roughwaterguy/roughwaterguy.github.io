Set WshShell = WScript.CreateObject("WScript.Shell")
WshShell.run "notepad"
WScript.sleep 200
WshShell.sendkeys "Get Rick Rolled Bitch!!!!"
WScript.sleep 100
WshShell.run "chrome"
WScript.sleep 1000
WshShell.sendkeys "https://www.youtube.com/watch?v=-AXetJvTfU0"
WScript.sleep 100
WshShell.sendkeys "{enter}"
WScript.sleep 4000
WshShell.sendkeys "ff"
X=MsgBox("Gotcha!!!!!",0+16,"Virus")
WScript.sleep 2000
WshShell.run "Rick.html"
